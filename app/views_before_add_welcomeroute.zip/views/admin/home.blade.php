@extends('layout')
@section('content')
<h1>
Welcome!
</h1>
<p>
Learning Laravel is a learning center. You can find everything about Laravel h\ere.
</p>
@stop