@section('title', 'Administrator :: '.TITLE_FOR_PAGES.'Add Restaurant')
@section('content')
<div class="clear"></div>
<div class="stade">
    <div class="wrapper">
        <div class="ptitle"><h1>
                How Do I Order?
            </h1>
        </div>
        <div class="pdescc">
            <iframe width="100%" height="539" src="https://www.youtube.com/embed/sexUO6ItimU" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
</div>
<div class="clear"></div>
@stop