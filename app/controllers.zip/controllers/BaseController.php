<?php

class BaseController extends Controller {

    /**
     * Setup the layout used by the controller.
     *
     * @return void
     */
    protected function setupLayout() {
        if (!is_null($this->layout)) {
            $this->layout = View::make($this->layout);
        }
    }

    public function createUniqueSlug($string = null, $model = null) {

        $string = substr(strtolower($string), 0, 35);
        if ($string == 0) {
            $string = "zero";
        }
        $old_pattern = array("/[^a-zA-Z0-9]/", "/_+/", "/_$/");
        $new_pattern = array("_", "_", "");
        $string = strtolower(preg_replace($old_pattern, $new_pattern, $string));
        $findData = DB::table($model)
                ->where('slug', $string)
                ->orderBy('id', 'desc')
                ->first();
        if (!empty($findData)) {
            $uniqueSlug = $string . '-' . time();
        } else {
            $uniqueSlug = $string;
        }


        return $uniqueSlug;
    }

    function userLoggedinCheck() {
        $user_id = Session::get('user_id');

        $userData = DB::table('users')
                ->where('id', $user_id)
                ->first();
        if (!empty($userData)) {
            return Redirect::to('/user/myaccount');
        } else {
            return Redirect::to('/user/login');
        }
    }

    function chkUserType($valid_user_type = null) {

        $user_id = Session::get('user_id');
        $userData = DB::table('users')
                ->where('id', $user_id)
                ->first();
        $user_type = $userData->user_type;
        if ($user_type != $valid_user_type) {
            return false;
        } else {
            return true;
        }
    }

    function getlatlong() {
        $key = "9dcde915a1a065fbaf14165f00fcc0461b8d0a6b43889614e8acdb8343e2cf15";
        $ip = $_SERVER["REMOTE_ADDR"];
        $url = "http://api.ipinfodb.com/v3/ip-city/?key=$key&ip=$ip&format=xml";
// load xml file
        $xml = simplexml_load_file($url);
// create a loop to print the element name and data for each node
        $array = array(
            'lat' => 0,
            'long' => 0
        );
        foreach ($xml->children() as $child) {
            if ($child->getName() == 'latitude') {
                $array['lat'] = $child;
            }if ($child->getName() == 'longitude') {
                $array['long'] = $child;
            }
        }
        return $array;
    }

    function humanTiming($time) {

        $time = time() - $time; // to get the time since that moment
        $time = ($time < 1) ? 1 : $time;
        $tokens = array(
            31536000 => 'year',
            2592000 => 'month',
            604800 => 'week',
            86400 => 'day',
            3600 => 'hour',
            60 => 'minute',
            1 => 'second'
        );

        foreach ($tokens as $unit => $text) {
            if ($time < $unit)
                continue;
            $numberOfUnits = floor($time / $unit);
            return $numberOfUnits . ' ' . $text . (($numberOfUnits > 1) ? 's' : '');
        }
    }

    function checkAPI($api_key = NULL) {
        $ak = APIKEY;
        if ($ak != $api_key) {
            echo $this->errorOutput('Wrong URL access');
            exit;
        }
    }

    function errorOutput($errormsg = null) {
        return '{"response_status":"error","response_msg":"' . $errormsg . '","response_data":""}';
    }

    function deActivateOutput($errormsg = null) {
        return '{"response_status":"Deactivated","response_msg":"' . $errormsg . '","response_data":""}';
    }

    function successOutput($successmsg = null) {
        return '{"response_status":"success","response_msg":"' . $successmsg . '","response_data":""}';
    }

    function output($output = null) {
        return '{"response_status":"success","response_data":' . $output . ',"response_msg":""}';
    }

    function outputresult($output = null, $errormsg = null) {
        return '{"response_status":"success","response_data":' . $output . ',"response_msg":"' . $errormsg . '"}';
    }

    function outputs($output = null, $total_data = null) {
        return '{"response_status":"success","response_data":' . $output . ',"total_data":' . $total_data . ',"response_msg":""}';
    }

    function outputwithError($output = null) {
        return '{"response_status":"error","response_msg":' . $output . ',"response_data":""}';
    }

    // push notifications for Android
    function send_fcm_notify($receiver_device_id, $message, $type) {

        // include config
        //$url = 'https://android.googleapis.com/gcm/send';
        $url = 'https://fcm.googleapis.com/fcm/send';
        $receiver_device_id = array($receiver_device_id);
        $message = $message;

        //   pr($receiver_device_id);

        if ($type == 'Restaurant' || $type == 'DeliveryPerson' || $type == 'KitchenStaff') {
            $keyyy = PUSH_NOTIFY_AUTH_KEY_REST_SIDE;
        } elseif ($type == 'Customer') {
            $keyyy = PUSH_NOTIFY_AUTH_KEY_CUST_SIDE;
        } 
        
//        elseif ($type == 'DeliveryPerson') {
//            $keyyy = PUSH_NOTIFY_AUTH_KEY_DP_SIDE;
//        } elseif ($type == 'KitchenStaff') {
//            $keyyy = PUSH_NOTIFY_AUTH_KEY_KS_SIDE;
//        }



        $fields = array(
            'registration_ids' => $receiver_device_id,
            'data' => $message,
        );

        $headers = array(
            'Authorization: key=' . $keyyy,
            'Content-Type: application/json'
        );
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
//        echo $result;
        // echo $receiver_device_id;
    }

    // push notifications for Iphone
    function send_iphone_notification($receiver_device_id, $message, $type) {

// Put your device token here (without spaces):

        $deviceToken = $receiver_device_id;
// Put your device token here (without spaces):
// Put your private key's passphrase here:
        $passphrase = '';


///////////////////////////////////////////////////////////////////////////////////

        $ctx = stream_context_create();

        if ($type == 'Restaurant' || $type == 'DeliveryPerson' || $type == 'KitchenStaff') {
            die;
            stream_context_set_option($ctx, 'ssl', 'local_cert', BASE_PATH . '/uploads/FDrestaurant.pem');
        } elseif ($type == 'Customer') {
            stream_context_set_option($ctx, 'ssl', 'local_cert', BASE_PATH . '/uploads/FDcustomer.pem');
        }
        
//        elseif ($type == 'DeliveryPerson') {
//            stream_context_set_option($ctx, 'ssl', 'local_cert', BASE_PATH . '/uploads/Delivery.pem');
//        } elseif ($type == 'KitchenStaff') {
//            stream_context_set_option($ctx, 'ssl', 'local_cert', BASE_PATH . '/uploads/Kitchen.pem');
//        }


        stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
        
        $mode = IPHONEMODE;

// Open a connection to the APNS server
//        $fp = @stream_socket_client(
//                        'ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
       
        $fp = @stream_socket_client(
                        $mode, $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);

        if (!$fp)
            return 1;
//            exit("Failed to connect: $err $errstr" . PHP_EOL);
//        echo 'Connected to APNS' . PHP_EOL;
// Create the payload body
        $body['aps'] = array(
            'alert' => $message['message'],
            'sound' => 'default',
            'body' => $message
        );
        /* $body['aps'] = array(
          'sound' => 'default',
          'body' => $message,
          'content-available' => 1
          ); */

// Encode the payload as JSON
        $payload = json_encode($body);


// Build the binary notification
//        $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
        $msg = chr(0) . @pack('n', 32) . @pack('H*', $deviceToken) . @pack('n', strlen($payload)) . $payload;
//echo '<pre>';print_r($msg);die;
// Send it to the server
        $result = fwrite($fp, $msg, strlen($msg));

//        print_r($result);die;
        
//        if (!$result)
//            echo 'Message not delivered' . PHP_EOL;
//        else
//            echo 'Message successfully delivered' . PHP_EOL;
// Close the connection to the server
        fclose($fp);
    }

}
