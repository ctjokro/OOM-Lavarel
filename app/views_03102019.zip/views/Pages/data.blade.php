<!--<div class="pdescc">
    {{ $pageDetail->description; }}
</div>-->

<div class="terms-popup-window">
    <div class="page-title">
        {{ $pageDetail->name; }}
    </div>
    <div class="term-content">
        {{ $pageDetail->description; }}
    </div>
</div>