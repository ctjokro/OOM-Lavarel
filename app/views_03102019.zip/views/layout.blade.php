
<!DOCTYPE HTML>
<html>
    <!--[if lt IE 7 ]><html class="no-js ie6" dir="ltr" lang="en-US"><![endif]-->
    <!--[if IE 7 ]><html class="no-js ie7" dir="ltr" lang="en-US"><![endif]-->
    <!--[if IE 8 ]><html class="no-js ie8" dir="ltr" lang="en-US"><![endif]-->
    <!--[if IE 9 ]><html class="no-js ie9" dir="ltr" lang="en-US"><![endif]-->
    <!--[if (gte IE 9)|!(IE)]><!-->
    <!--[if !IE]><!-->
    <!--<![endif]-->
    <head>
        <meta content="width=device-width, initial-scale=1" name="viewport">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>
        
        </title>
        
        
    </head>
    <body>
         @yield('content')
    </body>
</html>
