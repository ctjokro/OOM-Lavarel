@extends('layouts.default')
@section('content')

<div class="clear"></div>
<div class="aside_banner">
    <div class="container">
    <div class="not_found">
        <img src="{{ URL::asset('public/img/front') }}/404_img.png" alt="img" />
        </div>
    </div>
</div>
<div class="clear"></div>
@stop