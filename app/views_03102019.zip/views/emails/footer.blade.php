<tr>
    <td style="font-size:12px;color:#000; line-height:18px;">
        <p style="margin:10px 0 0;">If you need any assistance, please submit an inquiry in the support tab or email us at <a href="mailto:info@foodordering.com" style="color:#000; text-decoration: underline;"><?php echo MAIL_FROM; ?></a>.</p>
        <!--<p style="margin:10px 0 0;">Have Fun at <?php echo SITE_TITLE; ?> !!</p>-->

    </td>
</tr>
</table>
<!-- End Middle Content --> 
</td>
</tr>
<tr>
    <td>
        <!-- Begin Footer Notifications -->
        <table width="100%" style="border-top:1px solid #ddd;">
            <tr>
                <td style="font-size:11px; line-height:18px;">
                    <p style="margin:10px 0 0;color:#000;"> From <?php echo SITE_TITLE; ?> Team</p>
                </td>

            </tr>
        </table>
        <!-- End Footer Notifications -->
    </td>
</tr>
<tr>
    <td valign="top">
        <!-- Begin Footer -->
        <table width="100%" style="border-top:1px solid #ddd; background-color:#242424;">
            <!--#F76F24-->

        </table>
        <!-- End Footer -->
    </td>
</tr>
</table>

<table style="display: inline-block;
       text-align: center;
       width: 710px;">
    <tbody style="color: #929292;
           display: inline-block;
           font-family: arial;
           font-size: 14px;
           margin-top: 5px;">
        <tr>
            <td style="font-size:12px;">
                <p style="color:#000;">
                   <?php echo html_entity_decode(HTML::link('/terms_and_conditions', "Terms and Conditions", array('class' => '', 'title' => "Terms and Conditions"))); ?> | <?php echo html_entity_decode(HTML::link('/privacy_policy', "Privacy Policy", array('class' => '', 'title' => "Privacy Policy"))); ?> | <?php echo html_entity_decode(HTML::link('/about', "About Us", array('class' => '', 'title' => "About Us"))); ?> <br/>
                   Copyright &copy; <?php echo date('Y'); ?>  <a style="color:#000;" href="<?php echo HTTP_PATH ?>"> {{SITE_URL}}</a> All Rights Reserved <!--<div style="text-align: center;color: #000" class="_cttv"><span class="_cvv">{{ html_entity_decode(link_to('http://www.logicspice.com', 'Powered by Logicspice', array('escape' => false,'target'=>'_blank'))) }}</span></div>-->.</p>
            </td>
        </tr>
    </tbody>
</table>
</div>
</body>
</html>